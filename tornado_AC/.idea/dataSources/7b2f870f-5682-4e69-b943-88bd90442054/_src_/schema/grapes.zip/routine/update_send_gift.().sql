CREATE PROCEDURE `update_send_gift`()
  begin
 
update cookie_state set send_gift=0;
 
end